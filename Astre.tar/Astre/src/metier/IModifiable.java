package metier;

public interface IModifiable {

	boolean sauvegarder();
	boolean supprimer();
	
}
